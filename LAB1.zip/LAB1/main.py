import random
import math as math
from gmpy2 import mpz

print("Сумма ряда 0 - 999999")
a1 = 0
a_n = 999999
n = 1000000
ArrMedian = []
Mnogo = 1

S = (a1 + a_n)*n//2
midNumbers = (a_n-a1)/2

for i in range(1,1000001):
    ArrMedian.append(random.randint(1,10))
ArrMedian.sort()
S_Median = (ArrMedian[499999] + ArrMedian[500000])/2

print("Сумма ряда = ", S)
print("Среднее ряда = ", midNumbers)
print("Медиана рандомного ряда = ", S_Median)
print("Медианные значения: \n1)", ArrMedian[499999], "\n2)", ArrMedian[500000])
print("Произведение ряда случайных чисел: ", mpz(math.prod(ArrMedian)))